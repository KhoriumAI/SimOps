# Architecture Decision Record: Golden CHT Case Configuration

**Date:** 2026-01-13
**Status:** Accepted
**Context:** Creating a master OpenFOAM CHT template ("Golden Case") for automated thermal simulations.
**OpenFOAM Version:** OpenFOAM Foundation v13 (using `foamMultiRun`).

## Problem
Standard `chtMultiRegionFoam` tutorials from older OpenFOAM versions do not work out-of-the-box with OpenFOAM 13 due to significant changes in solver architecture (`foamMultiRun`), thermophysical property handling, and region scoping. Stability for "dirty" CAD is a primary requirement.

## Decisions

### 1. Solver Selection: `foamMultiRun`
- **Decision:** Use `foamMultiRun` instead of the legacy `chtMultiRegionFoam` application.
- **Reason:** `chtMultiRegionFoam` is deprecated/redirected in OF13. `foamMultiRun` is the native solver framework allowing modular coupling of fluid and solid regions.
- **Impact:** `controlDict` application set to `foamMultiRun`.

### 2. Thermophysical Properties Format
- **Decision:** Use `physicalProperties` instead of `thermophysicalProperties`.
- **Reason:** OF13 standardizes property file naming to `physicalProperties`.
- **Configuration (Fluid):**
  - Type: `heRhoThermo`
  - Transport: `sutherland`
  - Thermo: `hConst`
  - EquationOfState: `perfectGas`
  - Energy: `sensibleEnthalpy`
- **Configuration (Solid):**
  - Type: `heSolidThermo`
  - Transport: `constIsoSolid` (Note: `const` is deprecated/removed)
  - Thermo: `eConst`
  - Energy: `sensibleInternalEnergy` (Note: Solves for `e`, not `h`)

### 3. Solver Constraints & Solved Variables
- **Decision:** Configure `fvSolution` to solve for `e` (internal energy) in solid regions.
- **Reason:** The `heSolidThermo` package with `sensibleInternalEnergy` solves the internal energy equation.
- **Fix:** Added `e` and `eFinal` solver settings to `system/solid_heatsink/fvSolution`.

### 4. Pressure Initialization for Compressible Flow
- **Decision:** Initialize `p_rgh` to Atmospheric Pressure (101325 Pa).
- **Reason:** `heRhoThermo` calculates density `rho = p / RT`. If `p` (derived from `p_rgh`) is near zero (vacuum), density approaches zero, causing Floating Point Exceptions (FPE) in momentum/energy predictors.
- **Fix:** `0/region1/p_rgh` internal field and boundaries set to 101325 Pa.

### 5. Gravity Specification
- **Decision:** Define gravity `g` in `constant/region1/g` (per-region) AND `constant/g`.
- **Reason:** OF13 `foamMultiRun` (or the `heRhoThermo` module) strictly requires gravity to be defined within the region's constant directory (`constant/region1/g` was explicitly requested by error log).


### 6. Stability Measures (Hardened for Dirty CAD)
- **Decision:** Use robust numerical schemes and limiters to handle poor mesh quality (non-orthogonality > 60°, skewness, high aspect ratio).
- **Gradient Schemes:** `cellLimited Gauss linear 1` for all variables (`p_rgh`, `U`, `h`, `e`, `T`) to prevent unphysical extrapolation.
- **Laplacian Schemes:** `Gauss linear limited 0.5` (blended correction) for stability on distorted meshes.
- **Correctors:** `nNonOrthogonalCorrectors` set to **2** (increased from 1) to handle skewness.
- **Limiters:** (Disabled) `limitTemperature` via `fvOptions` caused region-pointer issues in `foamMultiRun`. Relying on `cellLimited` schemes for bounding.
- **Divergence Schemes:** `Gauss upwind` for transport/energy to ensure boundedness.
- **Relaxation:** `p_rgh`=0.7, `U/h/e`=0.3.

## Validated State
The case runs stably for 100+ iterations in steady-state mode with residuals converging.

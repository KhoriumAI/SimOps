=============================================================================
GOLDEN CHT CASE - MASTER TEMPLATE (OpenFOAM 13 / foamMultiRun)
=============================================================================

This directory contains a robust, validated OpenFOAM CHT (Conjugate Heat Transfer)
case template configured for OpenFOAM Foundation v13 using `foamMultiRun`.

STRUCTURE:
----------
0/              - Boundary conditions (fluid: region1, solid: solid_heatsink)
constant/       - Mesh and physical properties
system/         - Solver/Scheme settings (fvSchemes, fvSolution)
generate_test_geometry.py - Script to regenerate STL files

KEY CONFIGURATIONS (DO NOT CHANGE WITHOUT REVIEW):
--------------------------------------------------
1. Solver: `foamMultiRun` (OF13 native replacement for chtMultiRegionFoam)
2. Pressure: `p_rgh` MUST be initialized to 101325 Pa (Atmospheric).
   - `0/region1/p_rgh`
   - Using 0 Pa will cause FPE due to zero density in perfectGas equation.
3. Solid Physics: Uses `heSolidThermo` solving for `e` (Internal Energy).
   - `constant/solid_heatsink/physicalProperties`
   - `system/solid_heatsink/fvSolution` includes solver for `e`.
4. Fluid Physics: Uses `heRhoThermo` solving for `h` (Enthalpy).
   - `constant/region1/physicalProperties`
5. Gravity: Defined in `constant/region1/g`.

USAGE:
------
1. Generate Geometry (if needed):
   python3 generate_test_geometry.py

2. Run Meshing:
   blockMesh
   snappyHexMesh -overwrite
   splitMeshRegions -cellZones -overwrite

3. Run Solver:
   foamMultiRun

PYTHON SERIALIZATION KEYS:
--------------------------
The following variables in `system/controlDict` are intended for Python overrides:
- endTime: Number of iterations
- writeInterval: Output frequency

STABILITY NOTES:
----------------
- Schemes are set to `upwind` (first order) for robustness on dirty CAD.
- Relaxation factors are conservative (0.3 for equations).
- Turbulence is set to `laminar` by default. To enable turbulence:
  1. Modify `constant/region1/turbulenceProperties` (simulationType RAS).
  2. Ensure `0/region1/k`, `epsilon`, `nut`, `alphat` files exist.

TROUBLESHOOTING:
----------------
- "Floating point exception": Check `p_rgh` is 101325, not 0. Check T is > 0.
- "cannot find file .../g": Ensure `constant/region1/g` exists.
- "Unknown solver e": Ensure `fvSolution` has `e` entry for solids.

=============================================================================
